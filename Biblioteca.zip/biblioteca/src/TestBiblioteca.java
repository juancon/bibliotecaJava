
public class TestBiblioteca {

	public static void main(String[] args) {
		(new Biblioteca()).menu();
	}

}
